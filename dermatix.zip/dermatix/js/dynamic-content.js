// This script manages dynamic content.
(function ($) {
  $(document).ready(function () {
    
    // This is the actual JS script contained in an object.
    var dynamicContentObject = (function () {
      // INTERNAL VARIABLES AND FUNCTIONS.
      var _dynamicContentTypes = [
        { type: 'product',
          keywords: ['dermatix® acne scar', 'dermatix® ultra'],
          highlights: [3, 2]
        },
        { type: 'scar',
          keywords: ['cesarean scars', 'acne scars', 'everyday burns and scars'],
          highlights: [1, 3, 2]
        },
        { type: 'section',
          keywords: ['our scar treatments', 'the science of scars', 'scar stories']
        }
      ];

      // Returns the full URL including query string and hash, but exclude the domain name.
      var _getFullUrl = function (url) {
        return window.location.href.substr(window.location.href.indexOf(window.location.host) + window.location.host.length);
      };

      var _getDynamicContentKeywords = function() {
        var dynamicContentMetaData = localStorage.getItem('dynamicContentMeta');
        if (dynamicContentMetaData) {
          dynamicContentMetaData = JSON.parse(dynamicContentMetaData);
        } else {
          dynamicContentMetaData = { keywords: {} };
        }

        return dynamicContentMetaData.keywords;
      };

      // Trigger any dynamic content.
      var _triggerDynamicContent = function () {
        var homepageHighlights = $('#block-views-block-highlights-banner-block-1').find('.owl-slider-wrapper').data('owlCarousel');
        
        if (homepageHighlights) {
          var dynamicContentKeywords = _getDynamicContentKeywords();
          var dynamicContentTriggered = false;
          for (var i = 0; i < _dynamicContentTypes.length; i++) {
            if (('highlights' in _dynamicContentTypes[i]) && (_dynamicContentTypes[i].type in dynamicContentKeywords)) {
              for (var j = 0; j < _dynamicContentTypes[i].keywords.length; j++) {
                if ((dynamicContentKeywords[_dynamicContentTypes[i].type].indexOf(_dynamicContentTypes[i].keywords[j]) >= 0) && (_dynamicContentTypes[i].highlights.length > j)) {
                  console.log('highlights triggered:', _dynamicContentTypes[i].type, '-', _dynamicContentTypes[i].keywords[j], ' - highlight index:', _dynamicContentTypes[i].highlights[j]);
                  homepageHighlights.goTo(_dynamicContentTypes[i].highlights[j]);
                  dynamicContentTriggered = true;
                  break;             
                }
              }
            }

            if (dynamicContentTriggered) {
              break;
            }
          }
        }
      };

      // PUBLIC FUNCTIONS.
      var dynamicContentJS = {
        init: function () {
          // Get keywords.
          var dynamicContentMetaData = {
            'fullPath': _getFullUrl(window.location.href).toLowerCase(),
            'pageTitle': document.title.split("|")[0].trim(),
            'thumbnail': $('meta[property="og:image"]').attr("content"),
            'lastVisited': Date.now(),
            'keywords': {}
          };

          var keywords = $('meta').toArray().filter(function(v, i) { return v.name == 'keywords'; }).map(function(v, i) { return (v.content ? v.content : ''); }).join(',').split(',').map(function(v, i) { return v.toLowerCase(); });
          if (keywords.length > 0) {
            var hasDynamicContentKeywords = false;
            for (var i = 0; i < _dynamicContentTypes.length; i++) {
              dynamicContentMetaData.keywords[_dynamicContentTypes[i].type] = [];
              for (var j = 0; j < _dynamicContentTypes[i].keywords.length; j++) {
                if (keywords.indexOf(_dynamicContentTypes[i].keywords[j]) >= 0) {
                  dynamicContentMetaData.keywords[_dynamicContentTypes[i].type].push(_dynamicContentTypes[i].keywords[j]);
                  hasDynamicContentKeywords = true;
                  break;
                }
              }
            }

            // Save into browser local storage.
            if (hasDynamicContentKeywords) {
              console.log('new meta stored:', dynamicContentMetaData);
              localStorage.setItem('dynamicContentMeta', JSON.stringify(dynamicContentMetaData));
            }
          }
          
          // Update the display.
          _triggerDynamicContent();
        },
      }

      return dynamicContentJS;
    })();

    // Run the script.
    dynamicContentObject.init();
  });
})(jQuery)