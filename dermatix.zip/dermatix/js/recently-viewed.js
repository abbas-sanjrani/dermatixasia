// This script manages the recently viewed list.
(function ($) {
  $(document).ready(function () {
    
    // This is the actual JS script contained in an object.
    var recentlyViewedObject = (function () {
      // INTERNAL VARIABLES AND FUNCTIONS.
      var _recentlyViewedMax = 20;

      // Get article page type, if it's not article will don't have article type
      var _articleType = $('meta[property="og:type"]').attr("content");
      var _verifyArticleType;
      switch (_articleType) {
        case 'The science of scars':
            _verifyArticleType = true;
          break;
        case 'Scar stories':
            _verifyArticleType = true;
          break;
        default:
          _verifyArticleType = false;
          break;
      }

      // Returns the full URL including query string and hash, but exclude the domain name.
      var _getFullUrl = function (url) {
        return window.location.href.substr(window.location.href.indexOf(window.location.host) + window.location.host.length);
      };

      var _formatRelativeTime = function (previous) {
        var current = Date.now();
        var elapsed = current - previous;
        var msPerMinute = 60 * 1000;
        var msPerHour = msPerMinute * 60;
        var msPerDay = msPerHour * 24;
        var msPerMonth = msPerDay * 30;
        var msPerYear = msPerDay * 365;

        var relativeTimeValue = 1, relativeTimeType = 'second';
        if (elapsed < 0) {
          relativeTimeValue = 1; relativeTimeType = 'second';
        } else if (elapsed < msPerMinute) {
          relativeTimeValue = Math.round(elapsed / 1000); relativeTimeType = 'second';
        } else if (elapsed < msPerHour) {
          relativeTimeValue = Math.round(elapsed / msPerMinute); relativeTimeType = 'minute';
        } else if (elapsed < msPerDay) {
          relativeTimeValue = Math.round(elapsed / msPerHour); relativeTimeType = 'hour';
        } else if (elapsed < msPerMonth) {
          relativeTimeValue = Math.round(elapsed / msPerDay); relativeTimeType = 'day';
        } else if (elapsed < msPerYear) {
          relativeTimeValue = Math.round(elapsed / msPerMonth); relativeTimeType = 'month';
        } else {
          relativeTimeValue = Math.round(elapsed / msPerYear); relativeTimeType = 'year';
        }

        return 'Few ' + relativeTimeType + 's ago';
      };

      // Updates the recently viewed DOM.
      var _updateRecentlyViewDisplay = function () {
        var recentList = localStorage.getItem('recentlyViewed');
        if (recentList) {
          recentlyViewedList = JSON.parse(recentList);
        } else {
          recentlyViewedList = [];
        }

        var recentlyViewedItemDom = $('<div class="recently_viewed_item col-lg-4 col-md-6"><a href="" class="recently_viewed_title"><span></span></a><div class="recently_viewed_thumbnail_wrapper"><img class="recently_viewed_thumbnail" alt="" src="" title="" /></div><div class="recently_viewed_time"></div><span class="recently_viewed_article_tag"></span></div>')
        var recentlyViewedContainer = $('.recentlyViewedList');
        recentlyViewedContainer.empty();

        for (var i = 0; i < recentlyViewedList.length; i++) {
          var recentlyViewedItemHtml = recentlyViewedItemDom.clone();
          recentlyViewedItemHtml.find('.recently_viewed_title').attr('href', recentlyViewedList[i].fullPath);
          recentlyViewedItemHtml.find('.recently_viewed_title').attr('title', recentlyViewedList[i].pageTitle);
          recentlyViewedItemHtml.find('.recently_viewed_title span').html(recentlyViewedList[i].pageTitle);

          recentlyViewedItemHtml.find('.recently_viewed_thumbnail').attr('src', recentlyViewedList[i].thumbnail);
          recentlyViewedItemHtml.find('.recently_viewed_thumbnail').attr('alt', recentlyViewedList[i].pageTitle);
          recentlyViewedItemHtml.find('.recently_viewed_thumbnail').attr('title', recentlyViewedList[i].pageTitle);

          recentlyViewedItemHtml.find('.recently_viewed_article_tag').html(recentlyViewedList[i].articleTag);

          recentlyViewedItemHtml.find('.recently_viewed_time').html(_formatRelativeTime(recentlyViewedList[i].lastVisited));
          recentlyViewedContainer.append(recentlyViewedItemHtml);
        }
      };


      // PUBLIC FUNCTIONS.
      var recentlyViewedJS = {
        init: function () {
          if (_verifyArticleType) {
            // Create data of current page for the recently viewed object.
            var currentPageData = {
              'key': window.location.pathname.toLowerCase(),
              'fullPath': _getFullUrl(window.location.href).toLowerCase(),
              'pageTitle': document.title.split("|")[0].trim(),
              'thumbnail': $('meta[property="og:image"]').attr("content"),
              'articleTag': $('div[class*="sub-page-tag"] a').html(),
              'lastVisited': Date.now()
            };

            // Get recently viewed data object from browser local storage.
            var recentList = localStorage.getItem('recentlyViewed');
            if (recentList) {
              recentlyViewedList = JSON.parse(recentList);
            } else {
              recentlyViewedList = [];
            }

            // Check if current page is already somewhere in the recently viewed list. If yes, remove it.
            for (var i = 0; i < recentlyViewedList.length; i++) {
              if (recentlyViewedList[i].key == currentPageData.key) {
                recentlyViewedList.splice(i, 1);
                break;
              }
            }

            // Insert current page into first item of recently viewed. Trim length of list of more than max length.
            recentlyViewedList.unshift(currentPageData);
            if (recentlyViewedList.length > _recentlyViewedMax) {
              recentlyViewedList.pop();
            }

            // Save back into browser local storage.            
            localStorage.setItem('recentlyViewed', JSON.stringify(recentlyViewedList));
          }
          
          // Update the display.
          _updateRecentlyViewDisplay();
        },
      }

      return recentlyViewedJS;
    })();

    // Run the script.
    recentlyViewedObject.init();
  });
})(jQuery)