/**** Custom scripting ****/
(function ($, Drupal){
	"use strict";

	Drupal.behaviors.dermatix ={
		attach: function (context, settings){
			var subNavigationFirst;
			
			// Main menu redirect instead on expand and collapse when click
			$(".navbar-expand-lg .navbar-nav .nav-link").on("click", function (){
				window.location = $(this).attr("href");
			});

			// Insert element into main menu
			$("ul.navbar-nav li.menu-item--expanded ul.dropdown-menu li a").once().append("<span class='menu-selector'></span>");

			// Change lang to icon
			$("#navbar-main .recent-view-icon").once().html("").parent().once().addClass("recent-view-icon");
			$("#navbar-main .favourites-icon").once().html("").parent().once().addClass("favourites-icon");
			$("#navbar-main .globe-icon").once().html("").parent().once().addClass("globe-icon");

			$("#block-sidenavigation .side-lang-navigation li.globe-icon").on("mouseover", function (){
				$(this).addClass("active");
			});

			$("#block-sidenavigation .side-lang-navigation li.globe-icon").on("mouseout", function (){
				$(this).removeClass("active");
			});

			// Get regional site data
			if($("#block-footerregional").length > 0){
				$("#block-footerregional ul li a").attr("target", "_blank");
				
				var regionalSite = "";
				regionalSite += "<ul class='dropdown-menu'>"

				$("#block-footerregional ul li").each(function (){
					regionalSite += "<li class='dropdown-item'>"
					regionalSite += "<a href='" + $(this).find("a").attr("href") + "' target='_blank'>" + $(this).find("a").html() + "<span class='menu-selector'></span></a>"
					regionalSite += "</li>"
				});

				regionalSite += "</ul>"

				$("li.globe-icon").attr("class", "nav-item globe-icon menu-item--expanded dropdown").append(regionalSite);
			}

			/* if($("#navbar-main .side-lang-navigation").length > 0){
				var sideNavigation = "<ul region='header_form' class='clearfix nav navbar-nav side-lang-navigation stackable'><li class='nav-item'><a href='' class='nav-link'>Healthcare professionals</a></li></ul>";
				$("#navbar-main #block-sidenavigation").once().append(sideNavigation);
			} */



			// Insert Icon to the Footer Link
			$("#social-media .nav-item").children().map(function (){
				var socialClass = $(this).attr("class").split(' ')[1];
				switch (socialClass){
					case "facebook":
						$(".facebook").html('<i class="fa fa-facebook-official"></i>');
						break;
					case "twitter":
						$(".twitter").html('<i class="fa fa-twitter-square"></i>');
						break;
					case "youtube":
						$(".youtube").html('<i class="fa fa-youtube-play"></i>');
						break;
					case "instagram":
						$(".instagram").html('<i class="fa fa-instagram"></i>');
						break;
				}
			});

			if($(".sub-navigation-wrapper").length > 0){
				$(".sub-navigation-wrapper").once().closest(".views-element-container").addClass("sub-navigation");

				// Insert element into sub navigation
				$(".sub-navigation ul li:first-child").addClass("active");
			}

			// Anchor to section

			if($("#product-main-body").length > 0){
				$("#product-main-body").once().closest("#main").addClass("product-page");
			}

			// Anchor to section
			$(".sub-navigation ul li").once().on("click", function (event){
				event.preventDefault();

				$(".sub-navigation ul li").removeClass("active");
				$(this).addClass("active");

				if($("#product-main-body").length > 0){
					var anchorPoint = $(this).find("a").html().toLowerCase().replace(/\s+/g, "-");
					var extraMargin = 0;
					subNavigationFirst = $("[id*='" + $(".sub-navigation ul li").eq(0).find("a").html().toLowerCase().replace(/\s+/g, "-") + "']").offset().top;

					if(anchorPoint == "featured-reads"){
						extraMargin = 90;
					}else{
						extraMargin = 0;
					}

					$("html, body").animate({
						scrollTop: $("[id*='" + anchorPoint + "']").offset().top + extraMargin - 60
					}, 500);
				}else{
					var anchorPoint = $(this).index();
					subNavigationFirst = $(".article-teaser").eq(0).closest(".field--name-field-article-teaser").siblings(".field--name-field-title").offset().top;

					$("html, body").animate({
						scrollTop: $(".article-teaser").eq(anchorPoint).closest(".field--name-field-article-teaser").siblings(".field--name-field-title").offset().top - 60
					}, 500);
				}
			});

			// Article
			if($(".article-teaser-col").length > 0){
				$(".article-teaser-col").closest(".views-element-container").once().addClass("article-teaser");
			}

			if($(".field--type-viewsreference").length > 0){
				$(".article-teaser-container").closest(".field--type-viewsreference").once().addClass("article-teaser-view");
			}

			if($(".product-teaser-col").length > 0){
				$(".product-teaser-col").closest(".views-element-container").once().addClass("product-teaser");
			}

			if($(".product-type-2").length > 0){
				$(".product-type-2").closest(".product-usage").parent().addClass("product-type-2");

				$(".product-overview-container").addClass("product-type-2");
				$(".product-overview-container .product-content-usage ul li").eq(0).find("sup").html("1, 2, 3");
				$(".product-overview-container .product-content-usage ul li").eq(1).find("sup").html("4, 5, 6");
			}

			if($(".page-node-108 .product-type-3").length > 0){
				$(".product-type-3").closest(".product-usage").parent().addClass("product-type-3");

				$(".product-overview-container").addClass("product-type-3");
				$(".ultrakids_title").find("sup").html("1");
				$(".product-overview-container .product-content-usage ul li").eq(1).find("sup").html("2, 3, 4");
			}

			// Make article block clickable
			$(".article-teaser-container").on("click", function (){
				window.location = $(this).find(".article-title a").attr("href");
			});

			$(".scar-landing-wrapper .image-container").on("click", function (){
				window.location = $(this).closest(".left-card").find(".card-body .card-link a").attr("href");
			});

			// Article teaser carousel on mobile
			if($(".scar-landing-wrapper-mobile").length > 0){
				$(".scar-landing-box-wrapper .scar-landing-box").find(".left-card").remove();

				$(".scar-landing-wrapper-mobile .scar-landing-box").owlCarousel({
					autoplay: false,
					center: false,
					items: 2,
					rewindSpeed: 300,
					slideSpeed: 300,
					nav: false,
					dots: true,
				});
			}

			// Back to top smooth anchor
			$(".back-to-top a").once().on("click", function (event){
				event.preventDefault();

				$("html, body").animate({
					scrollTop: 0
				}, 500);
			});

			// Changes icon active icon
			const currentUrl = window.location.pathname;

			function activeIcon(url){
				$(".mobile-title").removeClass("active-color");
				switch (url){
					case "/":
						$(".mobile-title").eq(0).addClass("active-color");
						break;
					case "/our-scar-treatments":
						$(".mobile-title").eq(1).addClass("active-color");
						break;
					case "/the-science-of-scars":
						$(".mobile-title").eq(2).addClass("active-color");
						break;
					case "/scar-stories":
						$(".mobile-title").eq(3).addClass("active-color");
						break;
					default:
						break;
				}
			}
			activeIcon(currentUrl);

			// Mobile takeover function
			$(".mobile-menu--container").off("click").on("click", "#mobile-expand-menu", function (){
				$(".region-mobile-menu-takeover").toggleClass("show");
				$(".expand-menu-dot").toggleClass("active");
				$(".mobile-menu--container").siblings().toggleClass("d-none");


				if($(this).siblings().children().find("p").hasClass("active-color")){
					$(this).siblings().children().find("p").removeClass("active-color");
				}else{
					activeIcon(currentUrl);
				}

				if(window.innerWidth < 1023){
					$("#block-menarinilogo").find("img").attr("src", "/themes/custom/dermatix/images/dermatix/menarini-logo-mobile.png");
				}else{
					$("#block-menarinilogo").find("img").attr("src", "/themes/custom/dermatix/images/dermatix/menarini-desktop.png");
				}

				if($(".mobile_takeover--link.country-wrapper").hasClass("open") && $(".offcanvas-collapse").hasClass("open")){
					$(".mobile_takeover--link.country-wrapper").removeClass("open");
					$(".offcanvas-collapse").removeClass("open");
				}
			});

			$(".mobile_takeover--title .close-icon").off("click").on("click", function (){
				$(".region-mobile-menu-takeover").toggleClass("show");
				$(".expand-menu-dot").toggleClass("active");
				$(".mobile-menu--container").siblings().toggleClass("d-none");

				if($(this).siblings().children().find("p").hasClass("active-color")){
					$(this).siblings().children().find("p").removeClass("active-color");
				}else{
					activeIcon(currentUrl);
				}

				if(window.innerWidth < 480){
					$("#block-menarinilogo").find("img").attr("src", "/themes/custom/dermatix/images/dermatix/menarini-logo-mobile.png");
				}else{
					$("#block-menarinilogo").find("img").attr("src", "/themes/custom/dermatix/images/dermatix/menarini-desktop.png");
				}

				// Adjust article 16:9 height
				if($(".image-container").length > 0){
					$(".image-container").css({
						"height": $(".image-container").width() * 9 / 16
					});
				}
			});

			if($(".scar-stories").length > 0){
				$(".field--name-field-title").each(function (){
					if($(this).html() == "Cesarean scars"){
						$(this).addClass("mt-0");
					}
				});
			}

			// Get banner height and set for banner container
			(function getBannerHeight(){
				var bannerImageHeight = $(".banner-img").outerHeight();
				$(".banner-container").height(bannerImageHeight);
			})();

			// Product slider widget
			slider($("#slider-value").val(), $("#slider-max-value").val());

			function slider(currentValue, maxValue){
				$("#slider-slider").slider({
					range: "min", animate: true, value: currentValue, min: 1, max: maxValue, step: 1,
					slide: function (event, ui){
						$("#slider-value").val(ui.value);
						currentValue = $("#slider-value").val();
						$(".slider-image-container .slider-image").hide();
						$(".slider-image-" + currentValue).show();
						$(".slider-description").removeClass("active");
						$(".slider-description[data-value='" + currentValue + "']").addClass("active");
					}
				});
			}

			// Product carousel widget
			$(".owl-carousel-container").owlCarousel({
				autoplay: false,
				center: true,
				singleItem: true,
				items: 1,
				rewindSpeed: 300,
				slideSpeed: 300,
				nav: true,
				navText:['<img src="/themes/custom/dermatix/images/dermatix/articles/articles-carousel-arrow-left.png" />','<img src="/themes/custom/dermatix/images/dermatix/articles/articles-carousel-arrow-right.png" />'],
				navigation:true,
				navigationText: ['<img src="/themes/custom/dermatix/images/dermatix/articles/articles-carousel-arrow-left.png" />','<img src="/themes/custom/dermatix/images/dermatix/articles/articles-carousel-arrow-right.png" />'],
				dots: true,
				onResized: function (){
					$(".owl-carousel-container .owl-dots").css({
						"top": $(".owl-carousel-container .item img").height()
					});
				},
			});

			if($(".banner-col-container").length > 0){
				$(".banner-col-container").once().closest(".views-element-container").addClass("banner-container").find("div[class*='banner-title'], div[class*='banner-description']").addClass("container");
			}

			// Add class to main container for styling
			if($(".node--type-article-page").length > 0){
				$("#main").addClass("article-page");

				if($(".field--name-field-product-sub-page-tag a").html() == "Video"){
					$("#main").addClass("video-page");
					$(".field--name-field-product-sub-page-image").once().append("<img src='/themes/custom/dermatix/images/dermatix/video-play-button.png' class='play-button' alt='Play video' title='Play video' />");
				}

				$(".field--type-likebtn-field").appendTo(".paragraph--type--product-sub-page-banner .paragraph__column");

				if(!$(".field--name-field-related-articles").hasClass("field--label-above")){
					$(".field--name-field-related-articles").hide();
				}
			}

			$(".play-button").on("click", function (){
				$(this).closest(".paragraph--type--product-sub-page-banner").hide();
				$(".video-page .paragraph--type--bp-simple").show().find("iframe").once().attr("src", $(".video-page .paragraph--type--bp-simple").show().find("iframe").attr("src") + "?autoplay=1");
			});

			if($(".scar-landing-wrapper").length > 0){
				if($(".scar-landing-wrapper .image-card-wrapper .left-card .article-tag a").html() == "Video"){
					$(".scar-landing-wrapper .image-card-wrapper .left-card .image-container").once().append("<a href='" + $(".scar-landing-wrapper .image-card-wrapper .left-card .card-body .card-link a").attr("href") + "' class='card-play-button'><img src='/themes/custom/dermatix/images/dermatix/video-play-button.png' alt='Play video' title='Play video' /></a>");
				}
			}

			// Getting Article Content Link
			function getArticleContentLink(targetLink, replaceLink){
				let contentLink = $(targetLink).find("a").attr("href");
				let updateLink = $(replaceLink).find("a").attr("href", contentLink);
			}
			getArticleContentLink(".custom-card .card-link", ".card-body");


			// Remove unneed row class
			$(".scar-landing-cards-wrapper .view-content").removeClass("row");
			$(".scar-landing-cards-wrapper .view-content").addClass("card-deck");

			// Changing badge in article page 
			$(".collapse-badge").once().on("click", function (event){
				event.preventDefault();
				var badgeText = $(this).children().text();
				if(badgeText == '+'){
					$(this).children().text("–");
				}else{
					$(this).children().text("+");
				}
			});

			// FAQ filter
			if($("#views-exposed-form-frequently-asked-questions-block-1").length > 0){
				$("#main").addClass("faq-page");

				if($(".category-list").length > 0){
					$(".category-list").parent().addClass("category-item-list");
				}
			}

			// Sources collapse and expand
			$(".paragraph .field--name-field-sources .field__label").once().on("click", function (){
				if($(this).hasClass("expanded")){
					var crrThis = $(this);
					$(this).siblings(".field__item").slideUp(400, function (x){
						crrThis.removeClass("expanded");
					});
				}else{
					$(this).addClass("expanded").siblings(".field__item").slideDown(600);
				}
			});

			// Insert pruduct in Article Landing
			const splitUrl = currentUrl.split('/')[2];
			const dermatixUltra = $("#dermatix-ultra").html();
			const dermatixUltrakids = $("#dermatix-ultra-kids").html();
			const dermatixAcne = $("#dermatix-acne").html();

			switch (splitUrl){
				case "everyday-burns-and-scars":
					$("#block-dermatix-product-mobile").attr("href", "/our-scar-treatments/dermatix-ultra");
					$("#block-dermatix-product-mobile").html(dermatixUltra);
					break;
				case "acne-scars":
					$("#block-dermatix-product-mobile").attr("href", "/our-scar-treatments/dermatix-acne-scar");
					$("#block-dermatix-product-mobile").html(dermatixAcne).addClass("acne-block");
					break;
				case "cesarean-scars":
					$("#block-dermatix-product-mobile").attr("href", "/our-scar-treatments/dermatix-ultra");
					$("#block-dermatix-product-mobile").html(dermatixUltra);
					break;
				case "kids-scars":
					$("#block-dermatix-product-mobile").attr("href", "/our-scar-treatments/dermatix-ultra-kids");
					$("#block-dermatix-product-mobile").html(dermatixUltrakids);
					break;
			}

			// Where to buy
			if($(".where-to-buy-container").length > 0){
				$("#main").addClass("where-to-buy-page");
			}

			// Off Canvas Counrty's List
			$(".offcanvas").once().on("click", function (){
				$(".mobile_takeover--link.country-wrapper").toggleClass("open");
				$(".offcanvas-collapse").toggleClass("open");
			});

			if($(".node--type-article-type-landing-page").length > 0){
				$(".node--type-article-type-landing-page").find("#block-dermatixultra").find("#dermatix-ultra").on("click", function (){
					window.location = $(this).find(".feature-link").find(".field__item").eq(0).find("a").attr("href");
				});

				$(".node--type-article-type-landing-page").find("#block-dermatixacne").find("#dermatix-acne").on("click", function (){
					window.location = $(this).find(".feature-link").find(".field__item").eq(0).find("a").attr("href");
				});
			}
			
			// Quiz widget
			if($(".quiz-widget").length > 0){
				var correctAnswers = 0;
				
				$(".take-quiz-button").on("click", function(event){
					event.preventDefault();
					
					$(this).hide();
					$(".questions-container").show();
				});
				
				$(".answer-choice").on("click", function(){
					$(this).parent().find(".answer-choice").removeClass("active");
					$(this).addClass("active");
					
					if(!$(this).hasClass("correct-answer")){
						$(this).parent().siblings(".true-answer").show();
					}else{
						$(this).parent().siblings(".true-answer").hide();
					}
				});
				
				$(".next-button").once().on("click", function(event){
					event.preventDefault();
					var currentQuestion = $(".questions-container .question.current-question").index();
					currentQuestion += 1;
					
					$(".questions-container .question.current-question").hide().removeClass("current-question");
					$(".questions-container .question").eq(currentQuestion).show().addClass("current-question").find(".answer-choice").removeClass("active").parent().siblings(".true-answer").hide();
					
					if(currentQuestion > 0){
						if(currentQuestion == $(".question").length){
							$(".questions-container").hide();
							$(".result-container").show();
							
							if($(".questions-container .question .answer-choice.correct-answer.active").length >= 4){
								$(".result-qualified").show();
							}else{
								$(".result-unqualified").show();
							}
							
							$(".score-point").html($(".questions-container .question .answer-choice.correct-answer.active").length);
						}else{
							$(".back-button").show().css("display", "inline-block");							
						}
					}
				})
				
				$(".back-button").once().on("click", function(event){
					event.preventDefault();
					var currentQuestion = $(".questions-container .question.current-question").index();
					currentQuestion -= 1;
					
					if(currentQuestion >= 0){
						$(".questions-container .question.current-question").hide().removeClass("current-question");
						$(".questions-container .question").eq(currentQuestion).show().addClass("current-question").find(".answer-choice").removeClass("active").parent().siblings(".true-answer").hide();
					}
					
					if(currentQuestion <= 0){
						$(".back-button").hide();
					}
				})
				
				$(".retake-quiz-button").once().on("click", function(event){
					event.preventDefault();
					
					$(".questions-container").show().find(".question .answer-choice").removeClass("active");
					$(".result-container, .result-container div, .back-button").hide();
					$(".question-1").addClass("current-question").show();
				})
			}

			$(window).on("load", function (){
				if($(".highlights-banner-image").length > 0){
					$(".highlights-banner-image").each(function (){
						$(this).attr("style", "background-image:url(" + $(this).find("img").attr("src") + ");");
					});
				}

				if($(".banner-image").length > 0){
					$(".banner-image").attr("style", "background-image:url(" + $(".banner-image img").attr("src") + ");");
				}
				
				if($(".article-teaser-container").length > 0){
					$(".article-teaser-container").closest(".views-element-container").once().addClass("article-teaser");

					$(".article-teaser .article-teaser-container .article-title a").removeAttr("style");

					$(".article-teaser").each(function (){
						var containerHighestHeight = null;
						var containerHighHeight = 0;

						$(this).find(".article-teaser-container").each(function (){
							var containerHeight = $(this).find(".article-title a").height();

							if(containerHeight > containerHighHeight){
								containerHighHeight = containerHeight;
								containerHighestHeight = $(this).find(".article-title a").height();
							}

						});

						$(this).find(".article-teaser-container .article-title a").height(containerHighestHeight);
					});
				}

				if($(".product-teaser").length > 0){
					setTimeout(function(){
						if(window.innerWidth >= 768){
							$(".product-teaser .product-usage, .product-teaser .product-image").removeAttr("style");
					
							var usageHighestHeight = null;
							var imageHighestHeight = null;
							var usageHighHeight = 0;
							var imageHighHeight = 0;

							$(".product-teaser .product-teaser-col").each(function (){
								var usageHeight = $(this).find(".product-usage").height();
								var imageHeight = $(this).find(".product-image img").get(0).naturalHeight;

								if(usageHeight > usageHighHeight){
									usageHighHeight = usageHeight;
									usageHighestHeight = $(this).find(".product-usage").height();
								}

								if(imageHeight > imageHighHeight){
									imageHighHeight = imageHeight;
									imageHighestHeight = $(this).find(".product-image img").get(0).naturalHeight;
								}
							});

							$(".product-teaser .product-teaser-col").find(".product-usage").height(usageHighestHeight);
							$(".product-teaser .product-teaser-col").find(".product-image").height(imageHighestHeight);
						}else{
							$(".product-teaser .product-usage, .product-teaser .product-image").removeAttr("style");
						}
					}, 1000);
				}

				if($(".faq-carousel-container").length > 0){
					if(window.innerWidth >= 992){
						$(".faq-carousel-container").trigger("destroy.owl.carousel");
					}else{
						// FAQ carousel widget
						$(".faq-carousel-container").owlCarousel({
							autoplay: false,
							singleItem: true,
							items: 1,
							rewindSpeed: 300,
							slideSpeed: 300,
							nav: false,
							dots: true,
							onResized: function (){
								$(".owl-carousel-container .owl-dots").css({
									"top": $(".owl-carousel-container .item img").height()
								});
							},
						});
					}
				}

				if($(".owl-carousel-container").length > 0){
					// Position carousel widget pagination
					$(".owl-carousel-container .owl-dots").css({
						"top": $(".owl-carousel-container .item img").height()
					});
				}

				$(".owl-carousel").trigger("refresh.owl.carousel");

				if($("#block-views-block-highlights-banner-block-1").length > 0){
					$("#block-views-block-highlights-banner-block-1 .owl-wrapper .owl-item").each(function (){
						$(this).addClass($(this).find(".highlights-banner-type-of-scars").text().trim().toLowerCase().replace(/\s+/g, "-"));
					});
				}

				if($(".node--type-article-page").length > 0){
					$(".article-page .paragraph--type--bp-columns-two-uneven__2col-column2").stick_in_parent().on("sticky_kit:stick sticky_kit:unbottom", function (){
						$(".article-page .paragraph--type--bp-columns-two-uneven__2col-column2").parent().css("height", "100%");
					}).on("sticky_kit:unstick sticky_kit:bottom");
				}

				$(".back-to-top.fixed a").css({
					"right": (window.innerWidth - 1220) / 2 - 50
				});
				
				if($("div[region='highlighted']").length <= 0){
					if($(".node--type-article-page").length <= 0){
						$("#main-wrapper").addClass("no-banner");
					}
				}
			});
			
			$(window).on("scroll", function (){
				if($(".sub-navigation").length > 0){
					if($(window).scrollTop() <= subNavigationFirst){
						$(".sub-navigation ul li").removeClass("active").eq(0).addClass("active");
					}
				}

				if(window.innerWidth >= 1024){
					if($(window).scrollTop() > 300){
						if(($(window).scrollTop() + window.innerHeight) >= ($(".back-to-top").offset().top)){
							$(".back-to-top.fixed").addClass("bottomed");
						}else{
							$(".back-to-top.fixed").removeClass("bottomed");
							
							if(!$(".back-to-top.fixed a").is(":visible")){
								$(".back-to-top.fixed a").fadeIn("fast")
							}
						}
					}else{
						if($(".back-to-top.fixed a").is(":visible")){
							$(".back-to-top.fixed a").fadeOut("fast");
						}
					}
				}
			});

			$(window).on("resize", function (){
				if($(".owl-carousel-container").length > 0){
					// Position carousel widget pagination
					$(".owl-carousel-container .owl-dots").css({
						"top": $(".owl-carousel-container .item img").height()
					});
				}

				if($(".faq-carousel-container").length > 0){
					if(window.innerWidth >= 992){
						$(".faq-carousel-container").trigger("destroy.owl.carousel");
					}else{
						// FAQ carousel widget
						$(".faq-carousel-container").owlCarousel({
							autoplay: false,
							center: true,
							singleItem: true,
							items: 1,
							rewindSpeed: 300,
							slideSpeed: 300,
							nav: false,
							dots: true,
						});
					}
				}

				if($(".article-teaser-container").length > 0){
					$(".article-teaser .article-teaser-container .article-title a").removeAttr("style");

					setTimeout(function (){
						$(".article-teaser").each(function (){
							var containerHighestHeight = null;
							var containerHighHeight = 0;

							$(this).find(".article-teaser-container").each(function (){
								var containerHeight = $(this).find(".article-title a").height();

								if(containerHeight > containerHighHeight){
									containerHighHeight = containerHeight;
									containerHighestHeight = $(this).find(".article-title a").height();
								}

							});

							$(this).find(".article-teaser-container .article-title a").height(containerHighestHeight);
						});
					}, 100);
				}

				if($(".product-teaser").length > 0){
					if(window.innerWidth >= 768){
						$(".product-teaser .product-usage, .product-teaser .product-image").removeAttr("style");

						var usageHighestHeight = null;
						var imageHighestHeight = null;
						var usageHighHeight = 0;
						var imageHighHeight = 0;

						$(".product-teaser .product-teaser-col").each(function (){
							var usageHeight = $(this).find(".product-usage").height();
							var imageHeight = $(this).find(".product-image").height();

							if(usageHeight > usageHighHeight){
								usageHighHeight = usageHeight;
								usageHighestHeight = $(this).find(".product-usage").height();
							}

							if(imageHeight > imageHighHeight){
								imageHighHeight = imageHeight;
								imageHighestHeight = $(this).find(".product-image").height();
							}
						});

						$(".product-teaser .product-teaser-col").find(".product-usage").height(usageHighestHeight);
						$(".product-teaser .product-teaser-col").find(".product-image").height(imageHighestHeight);
					}else{
						$(".product-teaser .product-usage, .product-teaser .product-image").removeAttr("style");
					}
				}

				$(".back-to-top.fixed a").css({
					"right": (window.innerWidth - 1220) / 2 - 50
				});
			});

			setTimeout(function () {
				$(".recent-view-wrapper.mobile").toggleClass("d-none");
			}, 100);

			// Rencent view toggle
			$(".recent-view-item").off("click").on("click", function (event) {
				event.preventDefault();
				$(".recent-view-wrapper").toggleClass("show");
				$("#page").toggleClass("recent-view-show");

				$("html, body").animate({
					scrollTop: 0
				}, 100);
			})
		}
	};
})(jQuery, Drupal);