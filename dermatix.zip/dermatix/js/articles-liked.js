// This script manages the recently viewed list.
(function ($) {
	$(document).ready(function () {
		var ua = window.navigator.userAgent;
		var msie = ua.indexOf("MSIE ");
		var trident = ua.indexOf('Trident/');
		
		// This is the actual JS script contained in an object.
		var articlesLikedObject = (function () {
			// INTERNAL VARIABLES AND FUNCTIONS.
			var _articlesLikedMax = 20;
			var _articlesLikeRunned = 0;
			var _articlesLikedTypes = ["SCAR STORIES", "THE SCIENCE OF SCARS"];

			// Returns the full URL including query string and hash, but exclude the domain name.
			var _getFullUrl = function (url) {
				return window.location.href.substr(window.location.href.indexOf(window.location.host) + window.location.host.length);
			};

			var _formatRelativeTime = function (previous) {
				var current = Date.now();
				var elapsed = current - previous;
				var msPerMinute = 60 * 1000;
				var msPerHour = msPerMinute * 60;
				var msPerDay = msPerHour * 24;
				var msPerMonth = msPerDay * 30;
				var msPerYear = msPerDay * 365;

				var relativeTimeValue = 1, relativeTimeType = 'second';
				if (elapsed < 0) {
					relativeTimeValue = 1; relativeTimeType = 'second';
				} else if (elapsed < msPerMinute) {
					relativeTimeValue = Math.round(elapsed / 1000); relativeTimeType = 'second';
				} else if (elapsed < msPerHour) {
					relativeTimeValue = Math.round(elapsed / msPerMinute); relativeTimeType = 'minute';
				} else if (elapsed < msPerDay) {
					relativeTimeValue = Math.round(elapsed / msPerHour); relativeTimeType = 'hour';
				} else if (elapsed < msPerMonth) {
					relativeTimeValue = Math.round(elapsed / msPerDay); relativeTimeType = 'day';
				} else if (elapsed < msPerYear) {
					relativeTimeValue = Math.round(elapsed / msPerMonth); relativeTimeType = 'month';
				} else {
					relativeTimeValue = Math.round(elapsed / msPerYear); relativeTimeType = 'year';
				}

				return 'Few ' + relativeTimeType + 's ago';
			};

			// Updates the recently viewed DOM.
			var _updateArticlesLikedDisplay = function () {
				var recentList = localStorage.getItem('articlesLiked');
				if (recentList) {
					articlesLikedList = JSON.parse(recentList);
				} else {
					articlesLikedList = [];
				}

				var articlesLikedItemDom = $('<div class="articles_liked_item col-lg-4 col-md-6"><a href="" class="articles_liked_title"><span></span></a><div class="articles_liked_thumbnail_wrapper"><img class="articles_liked_thumbnail" alt="" src="" title="" /></div><div class="articles_liked_time"></div><span class="articles_liked_article_tag"></span></div>')
				var articlesLikedContainer = $('.articlesLikedList');
				articlesLikedContainer.empty();

				for (var i = 0; i < articlesLikedList.length; i++) {
					var articlesLikedItemHtml = articlesLikedItemDom.clone();
					articlesLikedItemHtml.find('.articles_liked_title').attr('href', articlesLikedList[i].fullPath);
					articlesLikedItemHtml.find('.articles_liked_title').attr('title', articlesLikedList[i].pageTitle);
					articlesLikedItemHtml.find('.articles_liked_title span').html(articlesLikedList[i].pageTitle);

					articlesLikedItemHtml.find('.articles_liked_thumbnail').attr('src', articlesLikedList[i].thumbnail);
					articlesLikedItemHtml.find('.articles_liked_thumbnail').attr('alt', articlesLikedList[i].pageTitle);
					articlesLikedItemHtml.find('.articles_liked_thumbnail').attr('title', articlesLikedList[i].pageTitle);

					articlesLikedItemHtml.find('.articles_liked_article_tag').html(articlesLikedList[i].articleTag);

					articlesLikedItemHtml.find('.articles_liked_time').html(_formatRelativeTime(articlesLikedList[i].lastVisited));
					articlesLikedContainer.append(articlesLikedItemHtml);
				}
			};


			// PUBLIC FUNCTIONS.
			var articlesLikedJS = {
				init: function () {
								console.log("loaded");
					// Run once only.
					if (!_articlesLikeRunned) {
						var articleType = $('meta[property="og:type"]').attr("content");
						if (_articlesLikedTypes.indexOf(articleType.toUpperCase()) >= 0) {
							$('.likebtn-button.lb-like').children(':first-child').once().on('click', function() {
								console.log("clicked");
								var articleTitle = document.title.split("|")
								var articleLikedList = false;

								// Create data of current page for the liked object.
								var currentPageData = {
									'key': window.location.pathname.toLowerCase(),
									'fullPath': _getFullUrl(window.location.href).toLowerCase(),
									'pageTitle': articleTitle[0].trim(),
									'thumbnail': $('meta[property="og:image"]').attr("content"),
									'articleTag': $('div[class*="sub-page-tag"] a').html(),
									'liked': null,
									'lastVisited': Date.now()
								};

								// Get liked data object from browser local storage.
								var likedList = localStorage.getItem('articlesLiked');
								if (likedList) {
									articlesLikedList = JSON.parse(likedList);
								} else {
									articlesLikedList = [];
								}

								// Check if current page is already somewhere in the liked list. If yes, remove it.
								for (var i = 0; i < articlesLikedList.length; i++) {
									if (articlesLikedList[i].key == currentPageData.key) {
										articlesLikedList.splice(i, 1);
										articleLikedList = true;
										break;
									}
								}
								
								// Check if current page exist and removed from the list. If no, add into the list
								if(!articleLikedList){
									// Insert current page into first item of liked articles. Trim length of list of more than max length.
									articlesLikedList.unshift(currentPageData);
									if (articlesLikedList.length > _articlesLikedMax) {
										articlesLikedList.pop();
									}
								}

								// Save back into browser local storage, if it's article pages.
								localStorage.setItem('articlesLiked', JSON.stringify(articlesLikedList));
							});

							$('.likebtn-button.lb-dislike').children(':first-child').on('click', function() {
								// Get liked data object from browser local storage.
								var likedList = localStorage.getItem('articlesLiked');
								if (likedList) {
									articlesLikedList = JSON.parse(likedList);
									articleKey = window.location.pathname.toLowerCase();

									// Check if current page is already somewhere in the liked list. If yes, remove it.
									for (var i = 0; i < articlesLikedList.length; i++) {
										if (articlesLikedList[i].key == articleKey) {
											articlesLikedList.splice(i, 1);
											break;
										}
									}

									// Save back into browser local storage, if it's article pages.
									localStorage.setItem('articlesLiked', JSON.stringify(articlesLikedList));
								}
							});
						}

						_articlesLikeRunned = 1;
					}
			
				// Update the display.
				_updateArticlesLikedDisplay();
				},
			}

			return articlesLikedJS;
		})();
		
		// Run the script.
		if(msie > 0 || trident > 0){
			if (typeof(LikeBtn) != "undefined") {
				LikeBtn.init();
				setTimeout(function(){
					articlesLikedObject.init();
				}, 500);
			}
		}else{
			window.addEventListener('load', function () {
				if (typeof(LikeBtn) != "undefined") {
					LikeBtn.init();
					setTimeout(function(){
						articlesLikedObject.init();
					}, 500);
				}
			});
		}
			
		if($("#page-wrapper.favourites").length > 0){
			setTimeout(function(){
				articlesLikedObject.init();
			}, 500);
		}
		
		/* $(window).bind("load", function() {
		    articlesLikedObject.init();
		}); */
		
		/* if(msie > 0 || trident > 0){
			articlesLikedObject.init();
		}else{
			window.addEventListener('load', function () {
				articlesLikedObject.init();
			});
		} */
	});
})(jQuery)