var serviceWorkerObj, serviceWorkerPromise;

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    serviceWorkerPromise = navigator.serviceWorker.register('service-worker.js');
    serviceWorkerPromise.then(swReg => {
      console.log('MAIN: service worker registered');
      serviceWorkerObj = swReg;      
    })
    .catch(err => {
      console.error('MAIN: service worker error', err);
    });
  });
}